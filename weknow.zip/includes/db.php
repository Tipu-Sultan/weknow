<?php
$host = 'sql309.infinityfree.com';
$username = 'if0_36826066';
$password = 'rhpSzCg137ZIy';
$database = 'if0_36826066_weknow';

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}



